<?php


/*  



This program is design by Mhuradz and Ace 
You can contact us by visiting the fb page https://www.facebook.com/mhuradz

*/
class Admin extends Controller {
    public function __construct() {
        $this->userModel = $this->model('Admins');
    }

    public function index() {
        // main page
        $data = [
            'title' => 'PMS Dashboard'
        ];

        $this->view('admin/index', $data);
    }

    public function profiles() {
        // it will show the profiles that has been created on the database
        $data = [
            'title' => 'PMS Profiles',
            'row' => $this->userModel->getData()
        ];

        $this->view('admin/profiles', $data);
    }

    public function add() {
        // this will show where you can add a profile or create user info
        $data = [
            'title' => 'PMS Add Profile'
        ];
        $this->view('admin/add_profile', $data);
    }

    public function viewProfile($a = ''){


        // it will show which profile has been access through the link if the value of $a will be empty it will automatically routed to profiles page
        $data = [
            'title' => 'PMS View Profile',
            'row' => $this->userModel->getInfo($a),
            'pet' => $this->userModel->getDogInfo($a)
        ];
        if(empty($a))
            header("Location:".URLROOT."/admin/profile");
         else
            $this->view('admin/viewProfile', $data);
    }

    public function appointment() {
        //it will show all the appointments that has been created
        $data = [
            'title' => 'PMS Appointment',
            'row' => $this->userModel->getAppointment()
        ];

        $this->view('admin/appointment', $data);
    }


    public function viewAppointment($a = ''){


        //since the appointment has different ID so this method it will get the pet ID to get the details of the pet and owner
        $ac = $this->userModel->getAppointmentInfo($a);
        $owner_id = $ac->owner_id;


        $data = [
            'title' => 'PMS Appointment Data',
            'appointment' => $this->userModel->getAppointmentInfo($a),
            'owner' => $this->userModel->getOwner($owner_id),
            'pet' => $this->userModel->getDogInfo($ac->pet_ID)
        ];

        if(empty($a))
            header("Location:".URLROOT."/admin/profile");
         else
            $this->view('admin/viewAppointment', $data);
    }


    public function services(){
        //this will show the services page
        $data = [
            'title' => 'PMS Services'
        ];

        $this->view('admin/services', $data);
    }

    public function about(){
        //this will show the about page
        $data = [
            'title' => 'PMS About'
        ];

        $this->view('admin/about', $data);
    }


    public function payment(){
        //this will show the about page
        $data = [
            'title' => 'PMS Payment'
        ];

        $this->view('admin/payment', $data);
    }



}
