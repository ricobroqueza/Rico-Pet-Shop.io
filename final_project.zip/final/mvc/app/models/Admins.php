<?php
class Admins {
    private $db;
    public function __construct() {
        $this->db = new Database;
    }


    public function getData(){

      $this->db->query('SELECT * FROM owner');

        $row = $this->db->resultSet();

        return $row;
    }


    public function getInfo($id){
    	$this->db->query('SELECT * FROM owner WHERE owner_id = :id');

    	//Bind value
        $this->db->bind(':id', $id);

        $row = $this->db->single();

        return $row;

    }

	public function getDogInfo($id){
    	$this->db->query('SELECT * FROM pet_reg WHERE owner_ID = :id');

    	//Bind value
        $this->db->bind(':id', $id);

        $row = $this->db->single();

        return $row;

    }


    public function getAppointment(){
    	$this->db->query('SELECT * FROM appointment');

        $row = $this->db->resultSet();

        return $row;
    }

    public function getAppointmentInfo($id){
    	$this->db->query('SELECT * FROM appointment WHERE appointment_id = :id');

    	//Bind value
        $this->db->bind(':id', $id);

        $row = $this->db->single();

        return $row;
    }

    public function getDogAppointment($id){
    	$this->db->query('SELECT * FROM pet_reg WHERE pet_ID = :id');

    	//Bind value
        $this->db->bind(':id', $id);

        $row = $this->db->single();

        return $row;
    }

    public function getOwner($id){
        $this->db->query('SELECT * FROM owner WHERE owner_ID = :id');

        //Bind value
        $this->db->bind(':id', $id);

        $row = $this->db->single();

        return $row;

    }



  }

