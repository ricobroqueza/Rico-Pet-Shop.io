<?php
class Admins {
    private $db;
    public function __construct() {
        $this->db = new Database;
    }


    public function getData(){

      $this->db->query('SELECT * FROM owner');

        $row = $this->db->resultSet();

        return $row;
    }


    public function getInfo($id){
    	$this->db->query('SELECT * FROM owner WHERE owner_id = :id');

    	//Bind value
        $this->db->bind(':id', $id);

        $row = $this->db->single();

        return $row;

    }

	public function getDogInfo($id){
    	$this->db->query('SELECT * FROM pet_reg WHERE owner_ID = :id');

    	//Bind value
        $this->db->bind(':id', $id);

        $row = $this->db->single();

        return $row;

    }


    public function getAppointment(){
    	$this->db->query('SELECT * FROM appointment');

        $row = $this->db->resultSet();

        return $row;
    }

    public function getAppointmentInfo($id){
    	$this->db->query('SELECT * FROM appointment WHERE appointment_id = :id');

    	//Bind value
        $this->db->bind(':id', $id);

        $row = $this->db->single();

        return $row;
    }

    public function getDogAppointment($id){
    	$this->db->query('SELECT * FROM pet_reg WHERE pet_ID = :id');

    	//Bind value
        $this->db->bind(':id', $id);

        $row = $this->db->single();

        return $row;
    }

    public function getOwner($id){
        $this->db->query('SELECT * FROM owner WHERE owner_ID = :id');

        //Bind value
        $this->db->bind(':id', $id);

        $row = $this->db->single();

        return $row;

    }
    
    
    public function addAppointment($data) {
    	
    	
    	$name = explode(' ', $data['name']);
    	
    	
    	//this will insert to owner db
    
    	$sql = "INSERT INTO `owner`(`owner_ID`, `fName`, `lName`, `gender`, `age`, `address`, `tel`, `occupation`) 
    			VALUES ('',:fname, :lname, 'male' ,'18',:address,:contact,'IT')";
    	
    	$this->db->query($sql);
    	
    	$this->db->bind(':fname', $name[0]);
    	$this->db->bind(':lname', $name[1]);
    	$this->db->bind(':address', $data['address']);
    	$this->db->bind(':contact', $data['contact']);
    	
    	$this->db->execute();
    	
    	
    	$owner_id = $this->db->insert_id();
    	
    	
    	//this data will insert to pet_reg db
    	
    	$sql2 = "INSERT INTO `pet_reg`(`pet_ID`, `owner_ID`, `sex`, `breed`, `color`, `species`, `petName`) 
    			VALUES ('',:owner_id, 'male','husky','black','dog',:pet_name)";
    	
    	$this->db->query($sql2);
    	
    	$this->db->bind(':owner_id', $owner_id);
    	$this->db->bind(':pet_name', $data['pet_name']);
    	
    	
    	$this->db->execute();
    	
    	
    	$pet_id = $this->db->insert_id();
    	
    	
    	//this will insert to appointment db
    	
    	$sql3 = "INSERT INTO `appointment`( `appointmentName`, `pet_ID`, `owner_id`, `date`, `time`, `created`) 
    			VALUES ('visit', :pet_id, :owner_id, :schedule, :time_sched, :date)";
    	$this->db->query($sql3);
    
    	//Bind values
    	$this->db->bind(':schedule', $data['s_date']);
    	$this->db->bind(':pet_id', $pet_id);
    	$this->db->bind(':owner_id', $owner_id);
    	$this->db->bind(':time_sched', $data['s_time']);
    	$this->db->bind(':date', $data['date']);
    
    	//Execute function
    	if ($this->db->execute()) {
    		return true;
    	} else {
    		return false;
    	}
    	
    }
    
    public function updateAppointment($data){
    	$sql = "UPDATE `appointment` SET `date`= :schedule,`time`= :time,`created`= :date WHERE appointment_id = :appointment_id";
    	$this->db->query($sql);
    
    	//Bind value
    	$this->db->bind(':appointment_id', $data['appointment_id']);
    	$this->db->bind(':schedule', $data['s_date']);
    	$this->db->bind(':time', $data['s_time']);
    	$this->db->bind(':date', $data['created']);
    
    	return $this->db->execute();
    
    }
    
    
    
    
    public function deleteAppointment($id){
    	$sql = "DELETE FROM `appointment` WHERE appointment_id = :id";
    	$this->db->query($sql);
    
    	//Bind value
    	$this->db->bind(':id', $id);
    
    	return $this->db->execute();
    
    }



  }